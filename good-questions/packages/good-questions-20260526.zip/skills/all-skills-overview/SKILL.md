---
name: ask-better-questions-overview
description: 当用户问"有什么技能"、"能帮我做什么"、"提问工具有哪些"、"如何提问"、"提问艺术"时触发。提供 7 个核心提问技能的总览和使用指南。
argument-hint: [可选：具体技能名称]
allowed-tools: Read
---

# 提问艺术 - 技能总览

## 7 个核心技能

| 技能 | Slash 命令 | 核心能力 |
|------|-----------|---------|
| 视角切换 | /perspective-shift | 从默认视角跳到新坐标 |
| 连续追问 | /iterative-why | 从现象深入到系统结构 |
| 反事实思维 | /what-if-thinking | 先怀疑现实，再重构现实 |
| 问题重构 | /problem-reframing | 重新定义问题本身 |
| 系统思维 | /systems-thinking | 把问题放进系统中理解 |
| 假设驱动 | /hypothesis-driven | 提出假设，用 MVP 验证 |
| 元认知校准 | /meta-cognition | 对自己的思考进行思考 |

## 主工作流

```
/ask-better-questions 你的问题
```

按顺序走完 7 步，系统性地深入思考。

## 参考文件

- **`references/skills-list.md`** - 完整技能列表